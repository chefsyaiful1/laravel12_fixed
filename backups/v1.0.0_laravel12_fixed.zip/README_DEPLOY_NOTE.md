# Deployment note - Modified Laravel structure (Laragon)

This Laravel app has been restructured for Laragon use.
- Entry point: index.php (root)
- Application path: /laravel_core
- To run: cd laravel_core && php artisan serve
